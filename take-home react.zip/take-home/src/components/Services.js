import React, { Component } from 'react'

export default class Services extends Component {
    render() {

        
            const ServiceList =  this.props.services.map(service =>(

                <div  key={service.id } className="col-md-12" >
                    <ul className="menu">
                        <li>
                        <a href={`#${service.id}`}onClick={(e)=>this.props.handleServiceClick(e, service)}  key={service.id }>
                        {service.attributes.name}
                     </a>

                        </li>

                    </ul>

                </div>
            ));
        return (
            <div className="row">
                                    <h3>Services </h3>

            {ServiceList}
        </div>
        )
    }
}

