import React, { Component } from 'react'

export default class result extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             serviceName:'',
             ProviderList:[],
             FilterList:[]
        }

    }
    
    
    render() {
        
        console.log(this.props.ProviderList)
      
      const dd =  this.props.ProviderList &&
            this.props.ProviderList.included &&
            this.props.ProviderList.included.map(provider =>
                {                

                  return  provider.attributes.service == this.props.serviceName ?(

                    this.props.ProviderList &&
            this.props.ProviderList.data &&
            this.props.ProviderList.data.map(providerdata =>
                {            
                    console.log(providerdata.relationships.schedules.data[0].id)   
                    
                    console.log("-------------------")

                  return  providerdata.relationships.schedules.data[0].id == provider.id ?(
                        <p className="provider">{providerdata.id}</p>

                    ):(null
                    )
                    

                }

                    )
                  ):( null)
            }
                    

                

            )

            

            
            
        return (
            <div className="row">
            {dd}          

  </div>
        )
    }
    
}




