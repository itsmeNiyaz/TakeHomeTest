
import React,  { useEffect } from 'react'
import { connect } from 'react-redux'
import { fetchProviders } from '../redux'
import Result  from './result'


  function Providers({serviceList, fetchProviders, serviceName}) {

    
    useEffect(() => {
      fetchProviders()
    }, [])


return serviceList.loading ? (
        <h2>loading  </h2>
    ):serviceList.error ? (
        <h2>{serviceList.error}</h2>

    ):
    ( 
    
        <div>
                      <h3>Providers List</h3>

<Result serviceName={serviceName}
ProviderList ={serviceList} ></Result>

      
        </div>
    
    )
        }
const getIncludeID = (ServiceName, ServiceList) =>
{

  ServiceList.included.map(include => {
    if(include.attributes.service)
    if(include.attributes.service == ServiceName){
   return include.id
    }else{
    return  null
    }

})

}

const mapStateToProps = state => {
    return {
        serviceList: state.providers
    }
  }
  
  const mapDispatchToProps = dispatch => {
    return {
      fetchProviders: () => dispatch(fetchProviders())
    }
  }
  
  export default connect(
    mapStateToProps,
    mapDispatchToProps
  )(Providers)



