import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Services from './components/Services'
import Axios from 'axios';
import { Provider } from 'react-redux'
import store from './redux/store'
import Providers from './components/providers'


class  App extends Component{
 constructor() {
   super()
 
   this.state = {
     services:[],
     filterServiceId:''
      
   };
 }
 



componentWillMount(){

  Axios.get("https://api.inquickerstaging.com/v3/winter.inquickerstaging.com/services")
  .then(response => 
    
    {
      this.setState({services:response.data.data});
    }
   // response.json()
   )
  .catch(err =>{
    const errMsg = err.message
  }
    )

}

handleServiceClick = (e, services) =>
{
  console.log(services.id)
  this.setState({filterServiceId:services.attributes.name })
}

render(){
  return (
<div className="container">
  <div className="hed">  <h1>Take home Assignment</h1></div>
      
        <hr />
        <div className="row">
          <div className="left">
            <Services
            services = {this.state.services}
            handleServiceClick={this.handleServiceClick}

            ></Services>
            </div>
            <Provider store={store}>

            <div className="right">
              <Providers serviceName= {this.state.filterServiceId} ></Providers>
              </div>

          </Provider>
          </div>
          </div>
    

  )
}
}

/*
function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}*/

export default App;
