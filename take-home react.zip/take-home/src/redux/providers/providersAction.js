import axios from 'axios'
import { FETCH_SERVICE_REQUEST,FETCH_SERVICE_FAILURE, FETCH_SERVICE_SUCCESS, FILTER_SERVICE } from './providersTypes'

export const fetchProviders=()=>{

    return (dispatch) => {

        dispatch(fetchServiceRequest())
        axios.get('https://api.inquickerstaging.com/v3/winter.inquickerstaging.com/providers?include=locations%2Cschedules.location&page%5Bnumber%5D=1&page%5Bsize%5D=10')
        .then(response=>{
console.log(response);
            const providers = response.data
            dispatch(fetchServiceSuccess(providers))
        }).catch(error=>{

            dispatch(fetchServiceFailure(error.message))
        })

    }
}

export const fetchServiceRequest=()=>{
    return {
        type:FETCH_SERVICE_REQUEST
    }
}

export const fetchServiceSuccess=providers=>{
    return {
        type: FETCH_SERVICE_SUCCESS,
        payload:providers
    }
}
export const fetchServiceFailure =error=>{
        return {
            type:FETCH_SERVICE_FAILURE,
            payload:error
        }
}
export const filterService =providers=>{
    return {
        type:FILTER_SERVICE,
        payload:providers
    }
}

