import {FETCH_SERVICE_FAILURE, FILTER_SERVICE,FETCH_SERVICE_REQUEST,FETCH_SERVICE_SUCCESS } from "./providersTypes"


const initialState = {
    loading:false,
    providers:[],
    filter:[],
    error:''
}

const reducer = (state=initialState, action)=>{
    switch(action.type){
        case FETCH_SERVICE_REQUEST:
            return {
                
                ...state,
                loading:true  
              }
        case FETCH_SERVICE_SUCCESS:
            return {
                loading: false,
                providers: action.payload,
                error: ''
              }
         case FETCH_SERVICE_FAILURE:
            return {
                loading: false,
                providers: [],
                error: action.payload
              }
        case FILTER_SERVICE:
            return {
                loading: false,
                providers: action.payload,
                error: ''
              }
          
          default: return state
            }

}

export default reducer